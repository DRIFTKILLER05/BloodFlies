param(
    [ValidateSet('Install', 'Uninstall')][string]$Action = 'Install',
    [string]$GamePath = (Split-Path -Parent $PSScriptRoot)
)
$ErrorActionPreference = 'Stop'
$GamePath = [IO.Path]::GetFullPath($GamePath)
if (-not (Test-Path -LiteralPath (Join-Path $GamePath 'Dishonored2.exe'))) {
    throw 'Place the BloodflySwarm folder beside Dishonored2.exe, or supply -GamePath.'
}
if (Get-Process -Name Dishonored2 -ErrorAction SilentlyContinue) { throw 'Close Dishonored 2 first.' }
$base = Join-Path $GamePath 'base'
$backup = Join-Path $GamePath '.bloodfly-swarm-backup'
$runtimeTarget = Join-Path $GamePath 'dinput8.dll'
$runtimePayload = Join-Path $PSScriptRoot 'dinput8.dll'
function Hash-File([string]$File) {
    $stream = [IO.File]::OpenRead($File)
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($sha.ComputeHash($stream)).Replace('-', '') }
    finally { $sha.Dispose(); $stream.Dispose() }
}
function Read-BE([byte[]]$Bytes, [int]$Offset, [int]$Count) {
    [uint64]$value = 0
    for ($i = 0; $i -lt $Count; $i++) { $value = ($value * 256) + $Bytes[$Offset + $i] }
    return $value
}
function Write-BE([byte[]]$Bytes, [int]$Offset, [int]$Count, [uint64]$Value) {
    for ($i = $Count - 1; $i -ge 0; $i--) {
        $Bytes[$Offset + $i] = [byte]($Value -band 255)
        $Value = $Value -shr 8
    }
}
function Set-Length([string]$File, [long]$Length) {
    $stream = [IO.File]::Open($File, 'Open', 'Write', 'None')
    try { $stream.SetLength($Length) } finally { $stream.Dispose() }
}
if ($Action -eq 'Uninstall') {
    $statePath = Join-Path $backup 'state.json'
    $state = Get-Content -LiteralPath $statePath -Raw | ConvertFrom-Json
    if ($state.catalog -notin @('game1_patch', 'game1_voidmod')) { throw 'Invalid backup catalog.' }
    $indexPath = Join-Path $base ($state.catalog + '.index')
    $resourcesPath = Join-Path $base ($state.catalog + '.resources')
    $originalIndex = Join-Path $backup 'original.index'
    if ((Hash-File $indexPath) -ne $state.installedIndexHash -or
        (Hash-File $resourcesPath) -ne $state.installedResourcesHash -or
        (Hash-File $originalIndex) -ne $state.originalIndexHash) {
        throw 'Files changed after installation. Restore the later mods first; refusing to overwrite them.'
    }
    if ($state.runtimeHash -and (Test-Path -LiteralPath $runtimeTarget) -and
        (Hash-File $runtimeTarget) -ne $state.runtimeHash) {
        throw 'Runtime DLL changed after installation; refusing to remove another loader.'
    }
    [IO.File]::WriteAllBytes($indexPath, [IO.File]::ReadAllBytes($originalIndex))
    Set-Length $resourcesPath $state.originalResourcesLength
    if ((Hash-File $resourcesPath) -ne $state.originalResourcesHash) { throw 'Resource restoration verification failed. Keep the backup.' }
    if ($state.runtimeHash -and (Test-Path -LiteralPath $runtimeTarget)) {
        Remove-Item -LiteralPath $runtimeTarget
    }
    # Keep the backup for inspection; renaming also allows a later fresh installation.
    $archivedBackup = $backup + '.removed-' + [DateTime]::UtcNow.ToString('yyyyMMddHHmmssfff')
    if (-not ([IO.Path]::GetFullPath($backup)).StartsWith($GamePath + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase) -or
        -not ([IO.Path]::GetFullPath($archivedBackup)).StartsWith($GamePath + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) {
        throw 'Backup archive path escaped the game folder.'
    }
    Move-Item -LiteralPath $backup -Destination $archivedBackup
    Write-Host 'Bloodfly Swarm removed. Previous mods restored.'
    return
}
if (Test-Path -LiteralPath $backup) { throw 'An installation backup already exists. Uninstall the previous installation first.' }
if (Test-Path -LiteralPath $runtimeTarget) { throw 'An existing dinput8.dll was found. Remove its owning mod first; this installer will not overwrite another loader.' }
$runtimeHash = Hash-File $runtimePayload
if ($runtimeHash -ne '9E543E3521C867C626BA073350010C5B5B3C25E2ACF2DD1536EFEDC1940F4EF5') { throw 'Runtime payload checksum mismatch. Extract a fresh copy of this release.' }
if ((Hash-File (Join-Path $GamePath 'Dishonored2.exe')) -ne 'B671F8249422862BF557D00AAB2F4BB671ED4515CC10AD8A8A9DECAD84516180') {
    throw 'Unsupported executable. This release supports the tested Windows Steam executable only; no game files were changed.'
}
$master = [Text.Encoding]::ASCII.GetString([IO.File]::ReadAllBytes((Join-Path $base 'master.index')))
$catalog = 'game1_patch'
$resourceId = 6
if ($master.Contains('game1_voidmod.resources')) {
    $catalog = 'game1_voidmod'
    $resourceId = 7
}
$indexPath = Join-Path $base ($catalog + '.index')
$resourcesPath = Join-Path $base ($catalog + '.resources')
[byte[]]$indexBytes = [IO.File]::ReadAllBytes($indexPath)
if ($indexBytes.Length -lt 36 -or $indexBytes[0] -ne 5 -or
    [Text.Encoding]::ASCII.GetString($indexBytes, 1, 3) -ne 'SER') { throw 'Unsupported game index.' }
$resourceStream = [IO.File]::OpenRead($resourcesPath)
try {
    $header = New-Object byte[] 4
    if ($resourceStream.Read($header, 0, 4) -ne 4 -or $header[0] -ne 4 -or
        [Text.Encoding]::ASCII.GetString($header, 1, 3) -ne 'SER') { throw 'Unsupported resource archive.' }
} finally { $resourceStream.Dispose() }
$targets = @{
    'generated/decls/entitydef/models/characters/animals/rat/devouring_swarm.def.decl' = 'normal.decl'
    'generated/decls/entitydef/models/characters/animals/rat/devouring_swarm_big.def.decl' = 'greater.decl'
    'generated/decls/entitydef/models/characters/animals/bloodfly/bloodflyswarm_infected_corpse.def.decl' = 'offspring.decl'
    'generated/decls/fx/models/effects/gameplay/powers/rat_swarm/rat/rat_despawn_01.fx.decl' = 'lifetime.fx.decl'
}
$found = @()
$cursor = 36
$entryCount = Read-BE $indexBytes 32 4
for ($entry = 0; $entry -lt $entryCount; $entry++) {
    if ($cursor + 4 -gt $indexBytes.Length) { throw 'Truncated index entry.' }
    $cursor += 4
    $names = @()
    for ($field = 0; $field -lt 3; $field++) {
        if ($cursor + 4 -gt $indexBytes.Length) { throw 'Truncated name length.' }
        $length = [BitConverter]::ToUInt32($indexBytes, $cursor)
        $cursor += 4
        if ($length -gt $indexBytes.Length - $cursor) { throw 'Truncated resource name.' }
        $names += [Text.Encoding]::UTF8.GetString($indexBytes, $cursor, $length)
        $cursor += $length
    }
    if ($cursor + 26 -gt $indexBytes.Length) { throw 'Truncated resource metadata.' }
    if ($targets.ContainsKey($names[2])) {
        $expectedType = if ($targets[$names[2]] -eq 'lifetime.fx.decl') { 'fx' } else { 'entityDef' }
        if ($names[0] -ne $expectedType) { throw 'Unexpected resource type.' }
        $found += @{ Name = $names[2]; Metadata = $cursor; Payload = [IO.File]::ReadAllBytes((Join-Path $PSScriptRoot $targets[$names[2]])) }
    }
    $cursor += 26
}
if ($cursor -ne $indexBytes.Length -or $found.Count -ne $targets.Count -or
    @($found.Name | Select-Object -Unique).Count -ne $targets.Count) { throw 'Unsupported index or missing mod resources.' }
$originalLength = (Get-Item -LiteralPath $resourcesPath).Length
$state = @{
    catalog = $catalog
    version = '0.1.23'
    runtimeHash = $runtimeHash
    originalResourcesLength = $originalLength
    originalIndexHash = Hash-File $indexPath
    originalResourcesHash = Hash-File $resourcesPath
}
[void](New-Item -ItemType Directory -Path $backup)
Copy-Item -LiteralPath $indexPath -Destination (Join-Path $backup 'original.index')
$state | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $backup 'pending.json') -Encoding UTF8
try {
    $stream = [IO.File]::Open($resourcesPath, 'Open', 'Write', 'None')
    try {
        [void]$stream.Seek(0, 'End')
        foreach ($target in $found) {
            $metadata = $target.Metadata
            $payload = $target.Payload
            Write-BE $indexBytes $metadata 8 $stream.Position
            Write-BE $indexBytes ($metadata + 8) 4 $payload.Length
            Write-BE $indexBytes ($metadata + 12) 4 $payload.Length
            $flags = Read-BE $indexBytes ($metadata + 24) 2
            Write-BE $indexBytes ($metadata + 24) 2 (($resourceId -shl 2) -bor ($flags -band 3))
            $stream.Write($payload, 0, $payload.Length)
        }
    } finally { $stream.Dispose() }
    [IO.File]::WriteAllBytes($indexPath, $indexBytes)
    $state.installedIndexHash = Hash-File $indexPath
    $state.installedResourcesHash = Hash-File $resourcesPath
    Copy-Item -LiteralPath $runtimePayload -Destination $runtimeTarget
    if ((Hash-File $runtimeTarget) -ne $runtimeHash) { throw 'Installed runtime checksum mismatch.' }
    $state | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $backup 'state.json') -Encoding UTF8
} catch {
    [IO.File]::WriteAllBytes($indexPath, [IO.File]::ReadAllBytes((Join-Path $backup 'original.index')))
    Set-Length $resourcesPath $originalLength
    if ((Test-Path -LiteralPath $runtimeTarget) -and (Hash-File $runtimeTarget) -eq $runtimeHash) {
        Remove-Item -LiteralPath $runtimeTarget
    }
    throw
}
Write-Host 'Bloodfly Swarm 0.1.23 installed: Twin Swarms, Rat Piper, corrected placement and timed despawn. Restart the game.'
