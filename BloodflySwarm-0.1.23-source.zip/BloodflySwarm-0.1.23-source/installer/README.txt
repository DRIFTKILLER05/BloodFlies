Bloodfly Swarm
Version 0.1.23

SHORT DESCRIPTION
Replace Devouring Swarm's rats with friendly, attacking bloodflies. Includes
working Twin Swarms and Rat Piper upgrades, timed despawn, and Greater Swarm
corpse infestations. No ReShade required.

DESCRIPTION
Turn Devouring Swarm into a cloud of living bloodflies. These are flying
bloodflies with their own attacks, replacing the summoned rats.

FEATURES
- Normal Swarm summons 25 bloodflies, matching the original rat count.
- Greater Swarm summons 60 bloodflies, matching the upgraded rat count.
- Summoned bloodflies are friendly to you and can attack NPCs, including civilians.
- Summons disappear after approximately 30 seconds.
- Twin Swarms allows two active summoned swarms. Casting a third removes the
  oldest. Without the upgrade, a new cast replaces the previous swarm.
- Rat Piper makes idle summoned swarms follow you. They retain their attacks and
  resume following when idle, until their individual summon timers expire.
- Only Greater Swarm can infect corpses and create additional bloodflies.
- Infection offspring remain friendly and persist after the summoned swarm ends.
  They do not follow you or count toward the summoned-swarm limit.
- Includes the tested correction for bloodflies spawning below slopes/platforms.
- Uses a standalone runtime DLL; no ReShade or separate trainer is required.

BEHAVIOR NOTES
The friendly-offspring change uses the shared infected-corpse definition. It also
makes bloodflies produced by wild corpse infections and infected rats friendly
to the player. It does not make every existing wild bloodfly swarm friendly.
Summoned bloodflies despawn; they do not perform the original rat fleeing animation.
Following and casting another swarm do not reset an older swarm's lifetime.

REQUIREMENTS
- Dishonored 2, Windows 64-bit, with the tested Steam executable.
- Windows PowerShell (included with Windows).
- The Devouring Swarm power; buy Twin Swarms and Rat Piper to use their features.

The installer checks the executable and refuses unsupported builds before
changing game files. Other storefronts/executable versions are not supported by
this release. No Node.js, Python, or Void Installer installation is required.
An existing registered Void Installer archive is supported.

INSTALLATION
1. Close Dishonored 2.
2. Extract the ZIP. Place its BloodflySwarm folder beside Dishonored2.exe.
   Example: SteamLibrary\steamapps\common\Dishonored2\BloodflySwarm
3. Open that folder and double-click Install.cmd.
4. Wait for the installation success message, then launch the game.
5. Test with freshly summoned swarms.

The installer patches four existing archive declarations and installs dinput8.dll
beside Dishonored2.exe. Keep the .bloodfly-swarm-backup folder it creates; removal
needs that backup. The game executable is not modified on disk.

UPDATING AND REMOVAL
Uninstall an older public release before installing this one. Private prototypes
must be removed using their original installers first. Close the game and run
Uninstall.cmd to restore the previous archive state and remove this runtime DLL.
If another archive mod was installed afterward, remove that later mod first.
The installer refuses to overwrite changed archives or an existing dinput8.dll.
Do not delete backups or another mod's DLL to bypass those checks.

COMPATIBILITY
Mods editing Devouring Swarm entities, infected-corpse bloodflies, or the rat
despawn effect can conflict. Other mods using dinput8.dll cannot be installed
alongside this release through this installer; DLL chaining is not provided.
Unrelated archive changes already present are preserved. Install order matters
when multiple mods patch the same archive.
Infinite Mana is a separate mod and is not included in this download.

TESTING AND SUPPORT
Placement, timed despawn, friendliness, Twin Swarms, and Rat Piper were confirmed
in gameplay on the tested Steam installation. Installer tests cover both standard
patch archives and registered Void archives, exact payloads, conflict refusal,
and restoration. Every mission and mod combination has not been tested.
For problems, include the mission/location, upgrades owned, and
BloodflySwarm-runtime.log from the game folder. This is a runtime diagnostic log,
not a complete crash dump.

CREDITS
Uses MinHook 1.3.4; its license and notices are included in MinHook-LICENSE.txt.
This is an unofficial mod for Dishonored 2.
