#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <objbase.h>
#include <stdio.h>
#include <stdarg.h>
#include "swarm-core.h"
#include "MinHook.h"

static HMODULE module, system_input;
static INIT_ONCE input_once = INIT_ONCE_STATIC_INIT, hooks_once = INIT_ONCE_STATIC_INIT;
static void *input_exports[6];
static uintptr_t game;
static HANDLE log_file = INVALID_HANDLE_VALUE;
static bool hooks_active;
static LookupEntity lookup_entity;
static RemoveEntity post_remove;
static void *remove_event;
static void (*original_idle)(void *);
static void *(*original_spawn)(void *, const Vec3 *);
static void (*original_retire)(void *);

static void log_message(const char *format, ...) {
    if (log_file == INVALID_HANDLE_VALUE) return;
    char line[1024];
    int prefix = snprintf(line, sizeof(line), "[%llu] ", (unsigned long long)GetTickCount64());
    va_list args;
    va_start(args, format);
    vsnprintf(line + prefix, sizeof(line) - (size_t)prefix - 3, format, args);
    va_end(args);
    size_t len = strlen(line);
    line[len++] = '\r'; line[len++] = '\n';
    DWORD written;
    WriteFile(log_file, line, (DWORD)len, &written, NULL);
    FlushFileBuffers(log_file);
}

static void open_log(void) {
    wchar_t path[32768];
    DWORD len = GetModuleFileNameW(module, path, 32768);
    if (!len || len >= 32700) return;
    wchar_t *end = wcsrchr(path, L'\\');
    if (!end) return;
    wcscpy(end + 1, L"BloodflySwarm-runtime.log");
    log_file = CreateFileW(path, FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE,
        NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
}

static void idle_hook(void *state) {
    original_idle(state);
    uint8_t *component = *(uint8_t **)((uint8_t *)state + 0x20);
    if (!component || *(uintptr_t *)component != game + 0x1c42098) return;
    void *entity = *(void **)(component + 0x10);
    void *world = *(void **)(game + 0x39a5290);
    if (!world || !entity || *(uintptr_t *)entity != game + 0x1ceea88) return;
    uint8_t *player = ((void *(*)(void *))(game + 0x8a8ba0))(world);
    if (!player || !is_timed_player_summon(entity, *(uint32_t *)(player + 0xa8), game + 0x1b611e8)) return;
    uint8_t *attributes = *(uint8_t **)(player + 0x408);
    if (!attributes) return;
    int32_t index = -1;
    ((int32_t *(*)(void *, int32_t *, void *))(game + 0x60ce50))
        (attributes, &index, (void *)(game + 0x398c788));
    uint8_t *values = *(uint8_t **)(attributes + 0x48);
    bool upgraded = values && index >= 0 && index < 65536 &&
        *(float *)(values + (size_t)index * 40 + 0x24) > 0.0f;
    if (follow_idle_summon(component, player, upgraded,
            (FollowEntity)(game + 0x6c1990), (SetDestination)(game + 0x6c1a20)))
        log_message("Rat Piper: summon %08x following player", *(uint32_t *)((uint8_t *)entity + 0xa8));
}

static void retire_hook(void *power) {
    if (remove_retiring_summon(power, game + 0x1ceea88, lookup_entity, post_remove, remove_event))
        log_message("native retirement: queued removal of previous summoned swarm");
    original_retire(power);
}

static void *spawn_hook(void *power, const Vec3 *target) {
    if (!target || !valid_position(*target)) return original_spawn(power, target);
    void *sensor = NULL;
    Vec3 surface, adjusted;
    const Vec3 *surface_ptr = NULL;
    memcpy(&sensor, (uint8_t *)power + 0xc8, sizeof(sensor));
    if (sensor && *(uintptr_t *)sensor == game + 0x1b3e7f8) {
        memcpy(&surface, (uint8_t *)sensor + 0x60, sizeof(surface));
        surface_ptr = &surface;
    }
    adjusted = spawn_position(*target, surface_ptr);
    void *entity = original_spawn(power, &adjusted);
    log_message("spawn: target %.3f %.3f %.3f -> %.3f %.3f %.3f; entity=%p",
        target->x, target->y, target->z, adjusted.x, adjusted.y, adjusted.z, entity);
    return entity;
}

static bool compatible_game(void) {
    wchar_t executable[32768];
    if (!GetModuleFileNameW(NULL, executable, 32768)) return false;
    const wchar_t *name = wcsrchr(executable, L'\\');
    if (!name || _wcsicmp(name + 1, L"Dishonored2.exe")) return false;
    game = (uintptr_t)GetModuleHandleW(NULL);
    IMAGE_DOS_HEADER *dos = (IMAGE_DOS_HEADER *)game;
    IMAGE_NT_HEADERS64 *pe = (IMAGE_NT_HEADERS64 *)(game + dos->e_lfanew);
    if (dos->e_magic != IMAGE_DOS_SIGNATURE || pe->Signature != IMAGE_NT_SIGNATURE ||
        pe->FileHeader.TimeDateStamp != 0x67a50cde || pe->OptionalHeader.SizeOfImage != 0x41cb000)
        return false;
    static const unsigned char idle_bytes[] = {0x48,0x89,0x5c,0x24,0x08,0x48,0x89,0x74,0x24,0x10,0x57,0x48,0x83,0xec,0x40,0x48};
    static const unsigned char attribute_bytes[] = {0x48,0x89,0x5c,0x24,0x08,0x48,0x89,0x74,0x24,0x10,0x48,0x89,0x7c,0x24,0x18,0x41};
    static const unsigned char player_bytes[] = {0x48,0x81,0xc1,0xb0,0x30,0x31,0,0x33,0xd2,0xe9,0x42,0xd3,0xf0,0xff,0xcc,0xcc};
    static const unsigned char follow_bytes[] = {0x48,0x89,0x5c,0x24,0x08,0x57,0x48,0x83,0xec,0x40,0x0f,0x29,0x74,0x24,0x30,0x48};
    static const unsigned char stop_bytes[] = {0x40,0x53,0x48,0x83,0xec,0x30,0xf3,0x0f,0x10,0x41,0x54,0xf3,0x0f,0x10,0x59,0x50};
    static const unsigned char spawn_bytes[] = {0x48,0x89,0x5c,0x24,0x20,0x55,0x56,0x57,0x41,0x56,0x41,0x57,0x48,0x81,0xec,0x80};
    static const unsigned char lookup_bytes[] = {0x89,0x4c,0x24,0x08,0x48,0x83,0xec,0x28,0x48,0x8b,0x0d,0x21,0x8d,0x2c,0x03};
    static const unsigned char remove_bytes[] = {0x48,0x83,0xec,0x28,0x45,0x33,0xc9,0xe8,0xc4,0x00,0x00,0x00,0x48,0x83,0xc4,0x28,0xc3};
    static const unsigned char retire_bytes[] = {0x40,0x53,0x48,0x83,0xec,0x20,0xf7,0x81,0xc0,0,0,0,0xff,0xff,0xff,0};
    return !memcmp((void *)(game+0x69fc80), idle_bytes, sizeof(idle_bytes)) &&
        !memcmp((void *)(game+0x60ce50), attribute_bytes, sizeof(attribute_bytes)) &&
        !memcmp((void *)(game+0x8a8ba0), player_bytes, sizeof(player_bytes)) &&
        !memcmp((void *)(game+0x6c1990), follow_bytes, sizeof(follow_bytes)) &&
        !memcmp((void *)(game+0x6c1a20), stop_bytes, sizeof(stop_bytes)) &&
        !memcmp((void *)(game+0x43da90), spawn_bytes, sizeof(spawn_bytes)) &&
        !memcmp((void *)(game+0x6dc560), lookup_bytes, sizeof(lookup_bytes)) &&
        !memcmp((void *)(game+0x883f60), remove_bytes, sizeof(remove_bytes)) &&
        !memcmp((void *)(game+0x43d9c0), retire_bytes, sizeof(retire_bytes));
}

static BOOL CALLBACK initialize_hooks(PINIT_ONCE once, PVOID parameter, PVOID *context) {
    (void)once; (void)parameter; (void)context;
    open_log();
    if (!compatible_game()) {
        log_message("DISABLED: unsupported executable or function signature mismatch");
        return TRUE;
    }
    lookup_entity = (LookupEntity)(game + 0x6dc560);
    post_remove = (RemoveEntity)(game + 0x883f60);
    remove_event = (void *)(game + 0x39a6f30);
    MH_STATUS status = MH_Initialize();
    if (status != MH_OK) { log_message("DISABLED: MH_Initialize %d", status); return TRUE; }
    status = MH_CreateHook((void *)(game + 0x69fc80), (void *)idle_hook, (void **)&original_idle);
    if (status == MH_OK)
        status = MH_CreateHook((void *)(game + 0x43da90), (void *)spawn_hook, (void **)&original_spawn);
    if (status == MH_OK)
        status = MH_CreateHook((void *)(game + 0x43d9c0), (void *)retire_hook, (void **)&original_retire);
    if (status == MH_OK) status = MH_QueueEnableHook((void *)(game + 0x69fc80));
    if (status == MH_OK) status = MH_QueueEnableHook((void *)(game + 0x43da90));
    if (status == MH_OK) status = MH_QueueEnableHook((void *)(game + 0x43d9c0));
    if (status == MH_OK) status = MH_ApplyQueued();
    if (status != MH_OK) {
        MH_Uninitialize();
        log_message("DISABLED: hook setup failed %d", status);
        return TRUE;
    }
    HMODULE pinned;
    GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_PIN,
        (LPCWSTR)(uintptr_t)initialize_hooks, &pinned);
    hooks_active = true;
    log_message("ENABLED 0.1.23: surface placement + 0.6m; native Twin Swarms limit; Rat Piper idle following; offspring excluded");
    return TRUE;
}

static BOOL CALLBACK initialize_input(PINIT_ONCE once, PVOID parameter, PVOID *context) {
    (void)once; (void)parameter; (void)context;
    // Explicit system-directory lookup prevents proxy recursion and preserves real DirectInput.
    wchar_t system_path[MAX_PATH];
    UINT length = GetSystemDirectoryW(system_path, MAX_PATH);
    if (!length || length + 13 >= MAX_PATH) return FALSE;
    wcscat(system_path, L"\\dinput8.dll");
    system_input = LoadLibraryExW(system_path, NULL, LOAD_LIBRARY_SEARCH_SYSTEM32);
    if (!system_input || system_input == module) return FALSE;
    const char *names[] = {"DirectInput8Create", "DllCanUnloadNow", "DllGetClassObject",
        "DllRegisterServer", "DllUnregisterServer", "GetdfDIJoystick"};
    for (unsigned i = 0; i < 6; ++i) {
        input_exports[i] = (void *)(uintptr_t)GetProcAddress(system_input, names[i]);
        if (!input_exports[i]) return FALSE;
    }
    return TRUE;
}

static bool ready_input(void) { return InitOnceExecuteOnce(&input_once, initialize_input, NULL, NULL) != FALSE; }

HRESULT WINAPI DirectInput8Create(HINSTANCE instance, DWORD version, REFIID iid, void **out, IUnknown *outer) {
    if (!ready_input()) return E_FAIL;
    InitOnceExecuteOnce(&hooks_once, initialize_hooks, NULL, NULL);
    return ((HRESULT (WINAPI *)(HINSTANCE,DWORD,REFIID,void **,IUnknown *))input_exports[0])(instance,version,iid,out,outer);
}
HRESULT WINAPI DllCanUnloadNow(void) {
    if (hooks_active) return S_FALSE;
    return ready_input() ? ((HRESULT (WINAPI *)(void))input_exports[1])() : S_FALSE;
}
HRESULT WINAPI DllGetClassObject(REFCLSID clsid, REFIID iid, void **out) {
    return ready_input() ? ((HRESULT (WINAPI *)(REFCLSID,REFIID,void **))input_exports[2])(clsid,iid,out) : E_FAIL;
}
HRESULT WINAPI DllRegisterServer(void) { return ready_input() ? ((HRESULT (WINAPI *)(void))input_exports[3])() : E_FAIL; }
HRESULT WINAPI DllUnregisterServer(void) { return ready_input() ? ((HRESULT (WINAPI *)(void))input_exports[4])() : E_FAIL; }
const void *WINAPI GetdfDIJoystick(void) { return ready_input() ? ((const void *(WINAPI *)(void))input_exports[5])() : NULL; }

BOOL WINAPI DllMain(HINSTANCE instance, DWORD reason, LPVOID reserved) {
    (void)reserved;
    if (reason == DLL_PROCESS_ATTACH) { module = instance; DisableThreadLibraryCalls(instance); }
    // Hooks remain valid until process exit; no engine calls or thread suspension under loader lock.
    return TRUE;
}
