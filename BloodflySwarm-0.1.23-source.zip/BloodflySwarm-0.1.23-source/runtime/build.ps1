$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$env:ZIG_GLOBAL_CACHE_DIR = Join-Path $PSScriptRoot 'cache-global'
$env:ZIG_LOCAL_CACHE_DIR = Join-Path $PSScriptRoot 'cache-local'
$zig = Join-Path $PSScriptRoot 'tools\zig-x86_64-windows-0.14.1\zig.exe'
New-Item -ItemType Directory -Path out -Force | Out-Null
& $zig cc -target x86_64-windows-gnu -std=c11 -O2 -Wall -Wextra -Werror test-core.c -o out/test-core.exe
if ($LASTEXITCODE) { throw 'Core test compilation failed.' }
& .\out\test-core.exe
if ($LASTEXITCODE) { throw 'Core tests failed.' }
& $zig cc -target x86_64-windows-gnu -std=c11 -O2 -Wall -Wextra -shared bloodfly-runtime.c dinput8.def vendor/minhook-1.3.4/src/hook.c vendor/minhook-1.3.4/src/buffer.c vendor/minhook-1.3.4/src/trampoline.c vendor/minhook-1.3.4/src/hde/hde64.c -I vendor/minhook-1.3.4/include -o out/dinput8.dll
if ($LASTEXITCODE) { throw 'Runtime compilation failed.' }
& $zig cc -target x86_64-windows-gnu -std=c11 -O2 -Wall -Wextra -Werror test-loader.c -o out/test-loader.exe
if ($LASTEXITCODE) { throw 'Loader test compilation failed.' }
& .\out\test-loader.exe
if ($LASTEXITCODE) { throw 'Loader smoke test failed.' }
Get-FileHash -LiteralPath out/dinput8.dll -Algorithm SHA256
