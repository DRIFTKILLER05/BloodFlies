#ifndef BLOODFLY_SWARM_CORE_H
#define BLOODFLY_SWARM_CORE_H
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>

typedef struct { float x, y, z; } Vec3;
typedef void *(*LookupEntity)(uint32_t);
typedef void (*RemoveEntity)(void *, void *, uint32_t);

static bool valid_position(Vec3 p) {
    return isfinite(p.x) && isfinite(p.y) && isfinite(p.z) &&
        fabsf(p.x) < 100000.0f && fabsf(p.y) < 100000.0f && fabsf(p.z) < 100000.0f;
}

static Vec3 spawn_position(Vec3 target, const Vec3 *surface) {
    Vec3 result = target;
    if (surface && valid_position(*surface)) {
        float dx = surface->x - target.x, dy = surface->y - target.y;
        // Use the cast sensor's collision-safe point only while it describes this cast.
        if (dx*dx + dy*dy <= 1.0f && fabsf(surface->z - target.z) <= 4.0f)
            result = *surface;
    }
    result.z += 0.6f;
    return result;
}

// Summons have our removal FX component; infection offspring do not. Inspect
// current objects rather than remembering pointers that become stale on load.
static bool is_timed_player_summon(void *entity, uint32_t player_id, uintptr_t fx_vtable) {
    if (!entity || *(uint32_t *)((uint8_t *)entity + 0xac) != player_id) return false;
    void **components = *(void ***)((uint8_t *)entity + 0x268);
    unsigned count = *(uint32_t *)((uint8_t *)entity + 0x270) & 0xffffffu;
    if (!components || count > 4096) return false;
    for (unsigned i = 0; i < count; ++i) {
        uint8_t *component = components[i];
        if (component && *(uintptr_t *)component == fx_vtable && component[0x44]) return true;
    }
    return false;
}

typedef void (*FollowEntity)(void *, void *, float);
typedef void (*SetDestination)(void *, const Vec3 *, float);

static bool follow_idle_summon(void *component, void *player, bool upgraded,
        FollowEntity follow, SetDestination stop) {
    void **groups = *(void ***)((uint8_t *)component + 0xb0);
    unsigned count = *(uint32_t *)((uint8_t *)component + 0xb8) & 0xffffffu;
    if (!groups || !count || count > 4096 || !groups[0]) return false;
    uint8_t *group = groups[0];
    uint32_t player_id = *(uint32_t *)((uint8_t *)player + 0xa8);
    bool following = *(uint32_t *)(group + 0x58) == player_id;
    // The vanilla Rat Piper path controls the first (idle) group. Attack groups
    // keep their existing targets and rejoin the idle group afterward.
    if (upgraded && !following && *(int32_t *)(group + 0x90) >= 3) {
        follow(group, player, 0.3f);
        return true;
    }
    if (!upgraded && following) {
        uint8_t *owner = *(uint8_t **)((uint8_t *)component + 0x10);
        if (owner) stop(group, (const Vec3 *)(owner + 0x300), 0.0f);
    }
    return false;
}

static bool remove_retiring_summon(void *power, uintptr_t bloodfly_vtable,
        LookupEntity lookup, RemoveEntity remove_entity, void *remove_event) {
    uint32_t *ids, packed;
    memcpy(&ids, (uint8_t *)power + 0xb8, sizeof(ids));
    memcpy(&packed, (uint8_t *)power + 0xc0, sizeof(packed));
    unsigned count = packed & 0xffffffu;
    if (!ids || !count || count > 4096) return false;
    void *entity = lookup(ids[0]);
    if (!entity || *(uintptr_t *)entity != bloodfly_vtable) return false;
    remove_entity(entity, remove_event, 0);
    // The native retirement routine performs its own list removal afterward.
    return true;
}
#endif
