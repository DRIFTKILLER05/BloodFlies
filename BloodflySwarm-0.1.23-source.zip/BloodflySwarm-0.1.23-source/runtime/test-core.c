#undef NDEBUG
#include <assert.h>
#include <stdio.h>
#include "swarm-core.h"

static uintptr_t entities[5] = {0, 0xb100, 0xb100, 0xb100, 0x1234};
static unsigned removed_ids[8], removed_count;
static void *lookup(uint32_t id) { return id && id < 5 ? &entities[id] : NULL; }
static void remove_one(void *entity, void *event, uint32_t delay) {
    assert(event == (void *)0x4444 && delay == 0);
    removed_ids[removed_count++] = (unsigned)((uintptr_t *)entity - entities);
}
static unsigned followed, stopped;
static void follow_one(void *group, void *player, float distance) {
    assert(distance == 0.3f);
    memcpy((uint8_t *)group+0x58, (uint8_t *)player+0xa8, 4);
    ++followed;
}
static void stop_one(void *group, const Vec3 *destination, float distance) {
    assert(destination->z == 14.5f && distance == 0.0f);
    *(uint32_t *)((uint8_t *)group+0x58) = 0x3fff0010;
    ++stopped;
}
int main(void) {
    Vec3 ground = {-4.957395f,62.056282f,13.783471f};
    Vec3 safe = {-4.932851f,62.030422f,13.907418f};
    Vec3 result = spawn_position(ground, &safe);
    assert(fabsf(result.z-14.507418f) < 0.0001f);
    assert(result.x == safe.x && result.y == safe.y);
    Vec3 invalid = {1e30f,1e30f,1e30f};
    assert(fabsf(spawn_position(ground,&invalid).z-ground.z-0.6f)<0.0001f);
    Vec3 stale = {100,100,100};
    assert(spawn_position(ground,&stale).x == ground.x);
    Vec3 platform = {ground.x,ground.y,ground.z+3.0f};
    assert(spawn_position(ground,&platform).z > platform.z);

    unsigned char power[0x120] = {0};
    uint32_t ids[] = {1,2};
    uint32_t *pointer = ids, packed = 0xab000002;
    memcpy(power+0xb8,&pointer,sizeof(pointer));
    memcpy(power+0xc0,&packed,sizeof(packed));
    assert(remove_retiring_summon(power,0xb100,lookup,remove_one,(void *)0x4444));
    assert(removed_count==1 && removed_ids[0]==1); // The second summon and offspring id 3 survive.
    uint32_t unchanged;
    memcpy(&unchanged,power+0xc0,sizeof(unchanged));
    assert(unchanged==packed && ids[0]==1 && ids[1]==2);
    ids[0]=4;
    assert(!remove_retiring_summon(power,0xb100,lookup,remove_one,(void *)0x4444));
    ids[0]=999;
    assert(!remove_retiring_summon(power,0xb100,lookup,remove_one,(void *)0x4444));
    packed=0;
    memcpy(power+0xc0,&packed,sizeof(packed));
    assert(!remove_retiring_summon(power,0xb100,lookup,remove_one,(void *)0x4444));
    unsigned char owner[0x380] = {0}, player[0x420] = {0}, fx[0x80] = {0};
    unsigned char component[0x2d0] = {0}, group[0xa0] = {0};
    *(uint32_t *)(player+0xa8)=42;
    *(uint32_t *)(owner+0xac)=42;
    *(float *)(owner+0x308)=14.5f;
    void *components[]={fx}, *groups[]={group};
    *(void ***)(owner+0x268)=components;
    *(uint32_t *)(owner+0x270)=0xab000001;
    *(uintptr_t *)fx=0xf100;
    fx[0x44]=1;
    assert(is_timed_player_summon(owner,42,0xf100));
    assert(!is_timed_player_summon(owner,43,0xf100));
    fx[0x44]=0;
    assert(!is_timed_player_summon(owner,42,0xf100)); // Untimed infection offspring.
    fx[0x44]=1;
    *(uintptr_t *)fx=0xf101;
    assert(!is_timed_player_summon(owner,42,0xf100));
    *(void **)(component+0x10)=owner;
    *(void ***)(component+0xb0)=groups;
    *(uint32_t *)(component+0xb8)=1;
    *(int32_t *)(group+0x90)=3;
    assert(!follow_idle_summon(component,player,false,follow_one,stop_one));
    assert(followed==0 && stopped==0);
    *(int32_t *)(group+0x90)=2;
    assert(!follow_idle_summon(component,player,true,follow_one,stop_one));
    *(int32_t *)(group+0x90)=3;
    assert(follow_idle_summon(component,player,true,follow_one,stop_one));
    assert(!follow_idle_summon(component,player,true,follow_one,stop_one));
    assert(followed==1 && stopped==0); // Do not restart the route every tick.
    assert(!follow_idle_summon(component,player,false,follow_one,stop_one));
    assert(stopped==1); // Loading an unupgraded player releases the follow target.
    *(uint32_t *)(component+0xb8)=0;
    assert(!follow_idle_summon(component,player,true,follow_one,stop_one));
    puts("PASS: placement, oldest-only retirement, expired handles, packed flags, summon identification, upgrade-gated following and release.");
}
