#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <objbase.h>
#include <stdio.h>
#undef NDEBUG
#include <assert.h>
int main(void) {
    HMODULE library = LoadLibraryW(L"out\\dinput8.dll");
    assert(library);
    const char *names[] = {"DirectInput8Create","DllCanUnloadNow","DllGetClassObject",
        "DllRegisterServer","DllUnregisterServer","GetdfDIJoystick"};
    for (unsigned i=0;i<6;++i) assert(GetProcAddress(library,names[i]));
    typedef HRESULT (WINAPI *Create)(HINSTANCE,DWORD,REFIID,void **,IUnknown *);
    Create create = (Create)(uintptr_t)GetProcAddress(library,"DirectInput8Create");
    GUID iid = {0xbf798031,0x483a,0x4da2,{0xaa,0x99,0x5d,0x64,0xed,0x36,0x97,0x00}};
    void *input = NULL;
    HRESULT hr = create(GetModuleHandleW(NULL),0x0800,&iid,&input,NULL);
    assert(SUCCEEDED(hr) && input);
    // The real system DirectInput interface uses the standard IUnknown ABI.
    IUnknown *unknown = (IUnknown *)input;
    unknown->lpVtbl->Release(unknown);
    const void *(WINAPI *get_format)(void) = (void *)GetProcAddress(library,"GetdfDIJoystick");
    assert(get_format());
    FreeLibrary(library);
    puts("PASS: all proxy exports, real DirectInput creation/release, system forwarding; non-game host stays unpatched.");
}
